---
title: Hello world!
author: bar
type: post
date: 2022-08-24T12:45:16+00:00
url: /2022/08/24/hello-world/
categories:
  - Uncategorized

---
Welcome to WordPress. This is your first post. Edit or delete it, then start writing!